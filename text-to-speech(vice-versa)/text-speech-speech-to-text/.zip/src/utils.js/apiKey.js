

export const apiKey = "5f6a72e9619240de9ea6104501fac39a"; // VoiceRSS API Key
